# 100 Days of Code Journal (1)

[Progress](https://www.notion.so/5e17a3e73ac74ab48fe3ba4bdcff1ddc)

**Quick Links** 🔗 

[**google.com**](http://www.google.com)

**[stackoverflow.com](http://www.stackoverflow.com)**

[**w3Schools.com**](https://www.w3schools.com/)

**[github.com](https://github.com/)**

**[github.com](https://github.com/)**

[Days](https://www.notion.so/ee45471099254b84aef6b09b093471a0)

<aside>
<img src="About%20Me%203941156bb5e94a3cba039307f8686a39/icons8-user_(1).gif" alt="About%20Me%203941156bb5e94a3cba039307f8686a39/icons8-user_(1).gif" width="40px" /> **Hi, I am Tony David**

I am the creator of this product. if you enjoyed this template, and would like to buy me a coffee ☕ you can do that [Here](https://www.buymeacoffee.com/tonydavid) 

If you have any questions or feedback reach me at notion.tony@gmail.com

<aside>
<img src="About%20Me%203941156bb5e94a3cba039307f8686a39/twitter.png" alt="About%20Me%203941156bb5e94a3cba039307f8686a39/twitter.png" width="40px" /> [Twitter](https://twitter.com/tonydavidz)

</aside>

<aside>
<img src="About%20Me%203941156bb5e94a3cba039307f8686a39/unnamed.png" alt="About%20Me%203941156bb5e94a3cba039307f8686a39/unnamed.png" width="40px" /> [More Notion Templates](https://tonydavid.gumroad.com/)

</aside>

![myimage-rounded-126.png](About%20Me%203941156bb5e94a3cba039307f8686a39/myimage-rounded-126.png)

</aside>

I'd greatly appreciate it if you could share your thoughts on your experience with this template. Your feedback is invaluable to me 👉

### Feedback Form